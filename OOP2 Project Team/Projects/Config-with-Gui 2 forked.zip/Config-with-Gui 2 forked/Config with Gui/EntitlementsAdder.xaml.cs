﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Leave.Modules;
using Leave.Supplements;


namespace Config_with_Gui {
	/// <summary>
	/// Interaction logic for EntitlementAdder.xaml
	/// </summary>
	public partial class EntitlementsAdder : Page
	{
		private UIElement baseControl;

		public EntitlementsAdder(UIElement baseControl)	{
			InitializeComponent();
			this.baseControl = baseControl;
			MainPage mainPage = baseControl as MainPage;
			this.Height = mainPage.Container.Height;
			this.Width	= mainPage.Container.Width;
		}

		public UIElement BaseControl { get { return baseControl; } }

		private void Page_Loaded(object sender, RoutedEventArgs e)	{
			if( ( baseControl as MainPage ).UserRole == "USER" )	{
				mainGrid.Visibility = System.Windows.Visibility.Collapsed;
				lb_message2.Visibility = System.Windows.Visibility.Visible;
				return;
			}
			MainPage mainPage = baseControl as MainPage;
			if(!mainPage.UserIsLoggedIn)	{
				(mainPage.BaseControl as MainWindow).Frame.Navigate(new LoginPage(baseControl));
			}

			icb_employees.Data			 = Employees.GetSpecificEmployeeInfo("DISTINCT EmployeeName");
			icb_leaveTypes.Data			 = Entitlements.GetSpecificEntitlementInfo("DISTINCT LeaveType");
			icb_entitlementType.Data	 = Entitlements.GetSpecificEntitlementInfo("DISTINCT EntitlementType");
			icb_validFrom.Data			 = Entitlements.GetSpecificEntitlementInfo("DISTINCT ValidFrom");
			icb_validTo.Data			 = Entitlements.GetSpecificEntitlementInfo("DISTINCT ValidTo");
		}

		private void ComboBox_Drop_Down_Opened(object sender, EventArgs e)	{
			(sender as IntelComboBox).ViewMatches();
		}

		private void Element_Text_Changed(object sender, TextChangedEventArgs e)	{
			if(sender is IntelComboBox)	{
				(sender as IntelComboBox).ViewMatches();
				if(sender == icb_employees)	{
					icb_employeeID.Data = Employees.GetSpecificEmployeeInfo("EmployeeID", "EmployeeName = '" + icb_employees.Text + "'");
					if( icb_employeeID.Items.Count > 0 )
						icb_employeeID.SelectedIndex = 0;
					if(icb_employeeID.Items.Count > 1)	{
						lb_employeeID.Visibility = System.Windows.Visibility.Visible;
						icb_employeeID.Visibility = System.Windows.Visibility.Visible;
					}	else	{
						lb_employeeID.Visibility = System.Windows.Visibility.Collapsed;
						icb_employeeID.Visibility = System.Windows.Visibility.Collapsed;
					}
				}
			}
			else if( sender == tb_balance )	{
			if( tb_balance.Text.Length == 0 )	{
				if( lb_message.Visibility == System.Windows.Visibility.Visible )
					lb_message.Visibility = System.Windows.Visibility.Collapsed;
				return;
			}
			double num;
			if( double.TryParse(tb_balance.Text, out num) )	{
				num *= 100;
				if(( int )num == num )	{
					if( lb_message.Visibility == System.Windows.Visibility.Visible )
						lb_message.Visibility = System.Windows.Visibility.Collapsed;
				}	else if( lb_message.Visibility == System.Windows.Visibility.Collapsed )	{
						lb_message.Visibility = System.Windows.Visibility.Visible;
					}
				}
			}
		}

		private void Button_Click(object sender, RoutedEventArgs e)	{
			StringBuilder values  = new StringBuilder( );
			StringBuilder columns = new StringBuilder( );

			if( icb_employeeID.Text.Length == 0 || icb_leaveTypes.Text.Length == 0 )	{
				MessageBox.Show( "Please enter the required fields." );
				return;
			}
			values.Append( icb_employeeID.Text + ", '" + icb_leaveTypes.Text + "'" );
			columns.Append( "EmployeeID, LeaveType" );

			if( icb_entitlementType.Text.Length != 0 ) {
				values.Append( ", '" + icb_entitlementType.Text + "'" );
				columns.Append( ", EntitlementType" );
			}
			if( icb_validFrom.Text.Length != 0 ) {
				values.Append( ", '" + icb_validFrom.Text + "'" );
				columns.Append( ", ValidFrom" );
			}
			if( icb_validTo.Text.Length != 0 ) {
				values.Append( ", '" + icb_validTo.Text + "'" );
				columns.Append( ", ValidTo" );
			}
			if( tb_balance.Text.Length != 0 ) {
				values.Append( ", " + tb_balance.Text );
				columns.Append( ", Balance" );
			}
			
			try	{
				Entitlements.AddEntitlementInfo( values.ToString( ), columns.ToString( ));
				MessageBox.Show( "Entitlements added successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information );
			}	catch(SqlException exception)	{
				MessageBox.Show( "Entitlements could not be added.\nAdditional information: " + exception.Message, "Failure", MessageBoxButton.OK, MessageBoxImage.Error );
			}
		}

		private static StringBuilder GetEmployeeIDRowConstraints(DataRowCollection rows)	{
			StringBuilder rowConstraints = new StringBuilder();
			int length = rows.Count;
			if(length == 0) return rowConstraints;
			rowConstraints.Append("EmployeeID IN(");
			for(int i = 0; i < length; i++)	{
				if(i > 0) rowConstraints.Append(", ");
				rowConstraints.Append(rows[i][0]);
			}
			rowConstraints.Append(")");
			return rowConstraints;
		}
	}
}
