﻿using System;

namespace Leave
{
	class DateString
	{
		private DateTime date;

		public DateString( object obj )	{
			if( obj is DateTime )	{
				this.date = ( DateTime )obj;
			}	else if( obj is string )	{
				string dateString = obj.ToString( );
				if(dateString[2] != '-' || dateString[5] != '-') throw new FormatException( "Invalid Date Format." );
				try	{
					date = new DateTime(int.Parse(dateString.Substring(6, 4)), int.Parse(dateString.Substring(0, 2)), int.Parse(dateString.Substring(3, 2)));
				}	catch(Exception exception)	{
					throw exception = new Exception( "Invalid Date Format!" );
				}
			}	else	{
				throw new ArgumentException( "Argument must be either a DateTime of a String" );
			}
		}

		public DateString( ) : this(DateTime.Today) { }

	//	public DateTime Date { get { return date; } }

		public DateTime ToDateTime( )	{
			return date;
		}

		public override string ToString()	{
			int day = date.Day;
			int month = date.Month;
			int year = date.Year;			return (date.Month < 10 ? "0" + date.Month : date.Month.ToString()) + "-" + (date.Day < 10 ? "0" + date.Day : date.Day.ToString()) + "-" + date.Year;		}

		public static implicit operator DateTime( DateString dateString )	{
			return dateString.ToDateTime( );
		}

		public static implicit operator string( DateString dateString )	{
			return dateString.ToString( );
		}
	}
}