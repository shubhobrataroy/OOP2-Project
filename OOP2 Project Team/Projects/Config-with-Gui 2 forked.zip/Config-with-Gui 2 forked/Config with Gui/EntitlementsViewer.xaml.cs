﻿using System;
using System.Data;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Automation.Peers;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Leave.Modules;
using Leave.Supplements;
using Leave.DataClients;

namespace Config_with_Gui	{
	/// <summary>
	/// Interaction logic for EntitlementsViewer.xaml
	/// </summary>
	public partial class EntitlementsViewer : Page
	{
		private UIElement baseControl;
		private DataManager dataManager;

		public EntitlementsViewer(UIElement baseControl)	{
			InitializeComponent();
			this.baseControl = baseControl;
			MainPage mainPage = baseControl as MainPage;
			this.Height = mainPage.Container.Height;
			this.Width	= mainPage.Container.Width;
			dataManager = new DataManager();
		}

		public UIElement BaseControl { get { return baseControl; } }

		private void Page_Loaded(object sender, RoutedEventArgs e)	{

		//	if user is not logged
		//	return to the login page
		//	else load required data
		//	and continue with the current view

			MainPage mainPage = baseControl as MainPage;
			if(!mainPage.UserIsLoggedIn)	{
				MainWindow mainWindow = mainPage.BaseControl as MainWindow;
				mainWindow.Frame.Navigate(new LoginPage(mainPage.BaseControl));
				return;
			}
		//	StringBuilder rowConstraints = GetEmployeeIDRowConstraints(Entitlements.GetSpecificEntitlementInfo("DISTINCT EmployeeID").Rows);
			string rowConstraints = "";
			if( mainPage.UserRole == "USER" ) rowConstraints = "Entitlements.EmployeeID = " + mainPage.EmployeeID;
			icb_employees.Data			 = Entitlements.GetSpecificDistributedEntitlementInfo( "DISTINCT Employees.EmployeeName", rowConstraints );
			icb_leaveTypes.Data			 = Entitlements.GetSpecificEntitlementInfo( "DISTINCT LeaveType", rowConstraints );
			icb_entitlementType.Data	 = Entitlements.GetSpecificEntitlementInfo( "DISTINCT EntitlementType", rowConstraints );
			icb_validFrom.Data			 = Entitlements.GetSpecificEntitlementInfo( "DISTINCT ValidFrom", rowConstraints );
			icb_validTo.Data			 = Entitlements.GetSpecificEntitlementInfo(" DISTINCT ValidTo", rowConstraints );
		}

		private void ComboBox_Drop_Down_Opened(object sender, EventArgs e)	{
			(sender as IntelComboBox).ViewMatches();
		}

		private void Element_Text_Changed(object sender, TextChangedEventArgs e)	{
			if(sender is IntelComboBox)	{
				(sender as IntelComboBox).ViewMatches();
				if(sender == icb_employees)	{
					icb_employeeID.Data = Entitlements.GetSpecificDistributedEntitlementInfo("DISTINCT Entitlements.EmployeeID", "EmployeeName = '" + icb_employees.Text + "'");
					if( icb_employeeID.Items.Count > 0 )	{
						icb_employeeID.SelectedIndex = 0;
					}
					if(icb_employeeID.Items.Count > 1)	{
						lb_employeeID.Visibility = System.Windows.Visibility.Visible;
						icb_employeeID.Visibility = System.Windows.Visibility.Visible;
					}	else	{
						lb_employeeID.Visibility = System.Windows.Visibility.Collapsed;
						icb_employeeID.Visibility = System.Windows.Visibility.Collapsed;
					}
				}
			}
			else if( sender == tb_balance )	{
				if( tb_balance.Text.Length == 0 )	{
					if( lb_message.Visibility == System.Windows.Visibility.Visible )
						lb_message.Visibility = System.Windows.Visibility.Collapsed;
					return;
				}
				double num;
				if( double.TryParse(tb_balance.Text, out num) )	{
					num *= 100;
					if(( int )num == num )	{
						if( lb_message.Visibility == System.Windows.Visibility.Visible )
							lb_message.Visibility = System.Windows.Visibility.Collapsed;
					}	else if( lb_message.Visibility == System.Windows.Visibility.Collapsed )	{
						lb_message.Visibility = System.Windows.Visibility.Visible;
					}
				}
			}
		}

	/*
		private void CheckBalance()	{
			try {
				if(tb_balance.Text.Length == 0 && lb_message.Visibility == System.Windows.Visibility.Visible)	{
					lb_message.Visibility = System.Windows.Visibility.Collapsed;
					return;
				}
				double.Parse(tb_balance.Text);
				for(int i = 0; i < tb_balance.Text.Length - 3; i++)	{
					if(tb_balance.Text[i] == '.' && lb_message.Visibility == System.Windows.Visibility.Collapsed)	{
						lb_message.Visibility = System.Windows.Visibility.Visible;
						return;
					}
				}
				if(lb_message.Visibility == System.Windows.Visibility.Visible)
					lb_message.Visibility = System.Windows.Visibility.Collapsed;
			}	catch(FormatException exception)	{
				if(lb_message.Visibility == System.Windows.Visibility.Collapsed)
					lb_message.Visibility = System.Windows.Visibility.Visible;
			}
		}
	 */

		public void ViewEntitlements( )	{
			Button_View_Click( btn_View, new RoutedEventArgs( ));
		}
		
		private void Button_View_Click(object sender, RoutedEventArgs e) {
			if( lb_message.Visibility == System.Windows.Visibility.Visible )	{
				MessageBox.Show( lb_message.Content.ToString( ), "Invalid Balance" );
				return;
			}
			if(( baseControl as MainPage ).UserRole == "USER" )	{
				FillDataGrid( dataManager.Data = Entitlements.GetAllDistributedEntitlementInfo( "Entitlements.EmployeeID = " + ( baseControl as MainPage ).EmployeeID ) );
				return;
			}
			StringBuilder rowConstraints = new StringBuilder( );
			if( icb_employeeID.Text.Length > 0 )	{
				rowConstraints.Append( "Entitlements.EmployeeID = " + icb_employeeID.Text );
			}	else	{
				rowConstraints.Append("1 = 1");
			}
			if(icb_leaveTypes.Text.Length > 0)
				rowConstraints.Append(" AND LeaveType = '" + icb_leaveTypes.Text + "'");
			
			if(icb_entitlementType.Text.Length > 0)
				rowConstraints.Append(" AND EntitlementType = '" + icb_entitlementType.Text + "'");
			
			if(icb_validFrom.Text.Length > 0 && icb_validTo.Text.Length > 0)
				rowConstraints.Append(" AND (ValidFrom = '" + icb_validFrom.Text + "' OR ValidTo = '" + icb_validTo.Text + "')");
			
			else if(icb_validFrom.Text.Length > 0)
				rowConstraints.Append(" AND ValidFrom = '" + icb_validFrom.Text + "'");
			
			else if(icb_validTo.Text.Length > 0)
				rowConstraints.Append(" AND ValidTo = '" + icb_validTo.Text + "'");
			
			if(tb_balance.Text.Length > 0)
				rowConstraints.Append(" AND Balance = " + tb_balance.Text);
			
			FillDataGrid( dataManager.Data = Entitlements.GetAllDistributedEntitlementInfo( rowConstraints.ToString( )));
		}

		private void Button_Delete_Click(object sender, RoutedEventArgs e)	{
			if(MessageBox.Show("Are you want to delete the selected data?", "Confirm", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)	{
				StringBuilder rowConstraints = new StringBuilder();
				for(int i = 0; i < dataGrid.SelectedItems.Count; i++)	{
					if(i > 0) rowConstraints.Append(" OR ");
					rowConstraints.Append("(EmployeeID = " + (dataGrid.SelectedItems[i] as DataRowView)[0] + " AND LeaveType = '" + (dataGrid.SelectedItems[i] as DataRowView)[1] + "')");
				}
				try {
					Entitlements.DeleteEntitlementInfo(rowConstraints.ToString());
				}	catch( System.Data.SqlClient.SqlException exception )	{
					MessageBox.Show( "Data could not be deleted!", "Failure", MessageBoxButton.OK, MessageBoxImage.Asterisk );
				}
			}
			Button_View_Click(btn_View, new RoutedEventArgs());
		}

		private void Button_Save_Click( object sender, RoutedEventArgs e )	{
			try {
				string fileName = ( baseControl as MainPage ).UserName;
				string delimiter = ", ";
				using(StreamWriter writer = new StreamWriter( fileName + ".csv" ))	{
					writer.WriteLine( dataManager.ExtractColumns( delimiter ));
					writer.WriteLine( dataManager.ExtractData( delimiter ));
				}
				MessageBox.Show("Data stored successfully at " + System.IO.Path.GetDirectoryName( System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase ) + "/" + fileName, "Success", MessageBoxButton.OK, MessageBoxImage.Information);
			}	catch( IOException exception )	{
				MessageBox.Show( "An unexpected error occured while saving data!", "Failure", MessageBoxButton.OK, MessageBoxImage.Asterisk );
			}
		}

		private void FillDataGrid( DataTable data )	{
		//	Fill the DataGrid
			dataGrid.ItemsSource = data.AsDataView( );
		//	Normalize the DataGridColumns
			foreach(DataGridColumn column in dataGrid.Columns)
				column.Width = new DataGridLength( 1.0, DataGridLengthUnitType.Star );
		}

		private void DataGrid_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)	{
			try {
				DataRowView row = dataGrid.SelectedItems[0] as DataRowView;
				TextBox textBox = e.EditingElement as TextBox;
				string column = e.Column.Header.ToString();
				string value = (column == "EmployeeID" || column == "Balance" ? textBox.Text : "'" + textBox.Text + "'");
				string changes = column + " = " + value;
				string rowConstraints = "EmployeeID = " + row[0] + " AND LeaveType = '" + row[2] + "'";
				Entitlements.UpdateEntitlementInfo( changes, rowConstraints );
				MessageBox.Show( "Changes saved!", "", MessageBoxButton.OK, MessageBoxImage.Information );
			}	catch( System.Data.SqlClient.SqlException exception )	{
				MessageBox.Show("Invalid Data!", "", MessageBoxButton.OK, MessageBoxImage.Error);
			}
		}
	}
}
