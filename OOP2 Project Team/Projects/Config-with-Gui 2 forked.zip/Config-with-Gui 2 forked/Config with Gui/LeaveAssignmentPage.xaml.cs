﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Leave;
using Leave.Modules;
using Leave.Supplements;

namespace Config_with_Gui
{
	/// <summary>
	/// Interaction logic for LeaveAssignmentPage.xaml
	/// </summary>
	public partial class LeaveAssignmentPage : Page
	{
		private UIElement baseControl;
		private double lostBalance = 0;

		public LeaveAssignmentPage(UIElement baseControl)	{
			InitializeComponent();
			this.baseControl = baseControl;
			MainPage mainPage = baseControl as MainPage;
			this.Height = mainPage.Container.Height;
			this.Width	= mainPage.Container.Width;
		}

		public UIElement BaseControl { get { return baseControl; } }

		private void Page_Loaded(object sender, RoutedEventArgs e)	{

			//	if user is not logged
			//	return to the login page
			//	else load required data
			//	and continue with the current view

			MainPage mainPage = baseControl as MainPage;
			if(!mainPage.UserIsLoggedIn)	{
				MainWindow mainWindow = mainPage.BaseControl as MainWindow;
				mainWindow.Frame.Navigate(new LoginPage(mainPage.BaseControl));
				return;
			}
			icb_employees.Data			 = Entitlements.GetSpecificDistributedEntitlementInfo("DISTINCT Employees.EmployeeName");
			icb_leaveTypes.Data			 = Entitlements.GetSpecificEntitlementInfo("DISTINCT LeaveType");
		}

		public void Load( )	{
			Page_Loaded( this, new RoutedEventArgs( ) );
		}

		private void DatePicker_SelectedDateChanged(object sender, SelectionChangedEventArgs e)	{
			if( dp_leavingDate.SelectedDate != null && dp_joiningDate.SelectedDate != null && dp_leavingDate.SelectedDate.Value >= dp_joiningDate.SelectedDate.Value )	{
				lb_message.Visibility = System.Windows.Visibility.Visible;
				lb_from.Visibility = System.Windows.Visibility.Collapsed;
				lb_to.Visibility = System.Windows.Visibility.Collapsed;
				cb_from.Visibility = System.Windows.Visibility.Collapsed;
				cb_to.Visibility = System.Windows.Visibility.Collapsed;
			}	else	{
				lb_message.Visibility = System.Windows.Visibility.Collapsed;
				lb_from.Visibility = System.Windows.Visibility.Visible;
				lb_to.Visibility = System.Windows.Visibility.Visible;
				cb_from.Visibility = System.Windows.Visibility.Visible;
				cb_to.Visibility = System.Windows.Visibility.Visible;
			}
			lb_balance.Content = GetBalance( );
		}

		
		private void ComboBox_SelectionChanged( object sender, SelectionChangedEventArgs e )	{
			lb_balance.Content = GetBalance( );
		}

		private void ComboBox_Text_Changed(object sender, TextChangedEventArgs e)	{
			( sender as IntelComboBox ).ViewMatches( );
			icb_employeeID.Data = Entitlements.GetSpecificDistributedEntitlementInfo("Entitlements.EmployeeID", "EmployeeName = '" + icb_employees.Text + "' AND LeaveType = '" + icb_leaveTypes.Text + "'");
			if( icb_employeeID.Data.Rows.Count > 0 )
				icb_employeeID.SelectedIndex = 0;
			if (icb_employeeID.Data.Rows.Count > 1) {
				lb_employeeID.Visibility  = System.Windows.Visibility.Visible;
				icb_employeeID.Visibility = System.Windows.Visibility.Visible;
			}	else	{
				lb_employeeID.Visibility  = System.Windows.Visibility.Collapsed;
				icb_employeeID.Visibility = System.Windows.Visibility.Collapsed;
			}
			lb_balance.Content = GetBalance( );
		}

		private object GetBalance( )	{
			if( lb_message.Visibility == System.Windows.Visibility.Visible || icb_leaveTypes.Text.Length == 0 || dp_leavingDate.SelectedDate == null || dp_joiningDate.SelectedDate == null || icb_employeeID.Text.Length == 0 ) return "";
			object balance = null;
			DataTable data = Entitlements.GetSpecificEntitlementInfo( "Balance, ValidFrom, ValidTo", "EmployeeID = " + icb_employeeID.Text + " AND LeaveType = '" + icb_leaveTypes.Text + "'" );
			DateTime leavingDate = dp_leavingDate.SelectedDate.Value;
			DateTime joiningDate = dp_joiningDate.SelectedDate.Value;
			if( leavingDate < new DateString( data.Rows[0][1].ToString( )) || joiningDate.AddDays( -1 ) > new DateString( data.Rows[0][2].ToString( ))) return "!!";
			balance = data.Rows[0][0];
			lostBalance = 0;
			DataTable holidays = WorkHolidays.GetAllHolidayInfo( );
			DataTable workingDays = WorkDays.GetWorkDayInfo( "WorkDayType NOT LIKE 'Non%'" );
			for(DateTime date = leavingDate; date < joiningDate; date = date.AddDays( 1 ))	{
				bool dayIsHoliday = false;
				foreach(DataRow row in holidays.Rows)	{
					if( date == ( DateTime )row[1] && row[2].ToString( ) == "Half Day" )	{
						lostBalance += .5;
						dayIsHoliday = true;
						break;
					}
				}
				if( dayIsHoliday ) continue;
				foreach(DataRow row in workingDays.Rows)	{
					if( row[1].ToString( ) == date.DayOfWeek.ToString( ))	{
						if( row[2].ToString( ) == "Half Day" ) lostBalance += .5;
						else lostBalance++;
						break;
					}
				}
			}
			lostBalance = ( lostBalance * ( cb_to.SelectedIndex - cb_from.SelectedIndex + 1 ) * .25 ) / 8;
		//	It was a tiresome balance calculation
		//	Alhamdu Lillaah!
			return (double.Parse( "0" + balance ) - lostBalance).ToString( );
		}

		public void AssignLeave( string employeeID, string leaveType, DateTime leavingDate, DateTime joiningDate )	{
			Page_Loaded(this, new RoutedEventArgs( ));
			icb_employeeID.Text = employeeID;
			icb_leaveTypes.Text = leaveType;
			dp_leavingDate.SelectedDate = leavingDate;
			dp_joiningDate.SelectedDate = joiningDate;
			MessageBox.Show( lb_balance.Content.ToString( ));
			Button_Click( button, new RoutedEventArgs( ));
		}

		private void Button_Click(object sender, RoutedEventArgs e) {
			if( icb_employeeID.Text.Length == 0 || icb_leaveTypes.Text.Length == 0 || dp_leavingDate.SelectedDate == null || dp_joiningDate.SelectedDate == null )	{
				MessageBox.Show("Please fill in the required fields.", "Incomplete", MessageBoxButton.OK, MessageBoxImage.Asterisk);
				return;
			}
			if( lb_message.Visibility == System.Windows.Visibility.Visible )	{
				MessageBox.Show( lb_message.Content.ToString( ), "Invalid Interval", MessageBoxButton.OK, MessageBoxImage.Error );
				return;
			}
			if( lb_balance.Content.ToString( ).Length == 0 )	{
				MessageBox.Show( "The data you inserted is not correct!", "Invalid Status", MessageBoxButton.OK, MessageBoxImage.Error );
				return;
			}
			if( double.Parse( lb_balance.Content.ToString( )) < 0 )	{
				if( MessageBox.Show("Balance is insufficient! Do you still want to continue?", "Insufficient Balance", MessageBoxButton.YesNo, MessageBoxImage.Exclamation) == MessageBoxResult.Cancel )	{
					return;
				}
			}
			string values = icb_employeeID.Text + ", '" + icb_leaveTypes.Text + "', '" + new DateString( dp_leavingDate.SelectedDate.Value ) + "', '" + new DateString( dp_joiningDate.SelectedDate.Value ) + "', " + lostBalance + ", '" + tb_commentBox.Text + "'";
			string changes = "Balance = " + lb_balance.Content;
			StringBuilder rowConstraints = new StringBuilder( "EmployeeID = " + icb_employeeID.Text + " AND LeaveType = '" + icb_leaveTypes.Text + "'" );
			StringBuilder dateConstraints = new StringBuilder( );
			try	{
				Entitlements.UpdateEntitlementInfo( changes, rowConstraints.ToString( ));
				LeaveList.AssignLeave( values );
				DataTable data = LeaveApplications.FetchDetails( "LeavingDate, JoiningDate", rowConstraints.ToString( ));
				foreach(DataRow row in data.Rows)	{
					if( new DateString( row[0].ToString( )) >= dp_leavingDate.SelectedDate && new DateString( row[1].ToString( )) <= dp_joiningDate.SelectedDate )	{
						dateConstraints.Append( "LeavingDate = '" + row[0] + "' AND JoiningDate = '" + row[1] + "' OR " );
					}
				}
				dateConstraints.Append( "1 = 2" );
				rowConstraints.Append( " AND (" + dateConstraints.ToString( ) + ")" );
				LeaveApplications.RejectApplications( rowConstraints.ToString( ));
				MessageBox.Show( "Leave Assigned Successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information );
			}	catch(System.Data.SqlClient.SqlException exception)	{
				MessageBox.Show(exception.Message);
			}
		}
	}
}
