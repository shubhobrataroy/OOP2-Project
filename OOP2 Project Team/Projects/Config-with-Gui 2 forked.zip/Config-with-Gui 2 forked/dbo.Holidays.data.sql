﻿INSERT INTO [dbo].[Holidays] ([Name], [Start Date], [End Date], [Holiday Type], [Repeats Annually]) VALUES (N'Independence Day', N'2016-04-26', N'2016-04-26', N'Full day', N'Yes')
INSERT INTO [dbo].[Holidays] ([Name], [Start Date], [End Date], [Holiday Type], [Repeats Annually]) VALUES (N'Victory Day', N'2016-12-16', N'2016-12-16', N'Full Day', N'Yes')
INSERT INTO [dbo].[Holidays] ([Name], [Start Date], [End Date], [Holiday Type], [Repeats Annually]) VALUES (N'No fixed', N'2016-04-15', N'2016-04-15', N'Full Day', N'Yes')
INSERT INTO [dbo].[Holidays] ([Name], [Start Date], [End Date], [Holiday Type], [Repeats Annually]) VALUES (N'Eid', N'2016-03-03', N'2016-03-03', N'Half Day', N'Yes')
