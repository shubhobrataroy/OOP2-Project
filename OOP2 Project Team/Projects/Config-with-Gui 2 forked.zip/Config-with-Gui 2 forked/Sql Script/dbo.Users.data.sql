INSERT INTO [dbo].[Users] ([UserName], [UserPass], [UserRole], [EmployeeID]) VALUES (N'DiptaGomes', N'#oop2', N'ADMIN', 2)
INSERT INTO [dbo].[Users] ([UserName], [UserPass], [UserRole], [EmployeeID]) VALUES (N'Grimmscorpp', N'#void', N'ADMIN', 1)
INSERT INTO [dbo].[Users] ([UserName], [UserPass], [UserRole], [EmployeeID]) VALUES (N'Ikram Khan', N'#void', N'USER', 1)
