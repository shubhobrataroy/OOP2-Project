INSERT INTO [dbo].[LeavePeriods] ([StartingDate], [EndingDate]) VALUES (N'01-01-2016', N'12-31-2016')
INSERT INTO [dbo].[LeavePeriods] ([StartingDate], [EndingDate]) VALUES (N'01-01-2017', N'12-31-2017')
INSERT INTO [dbo].[LeavePeriods] ([StartingDate], [EndingDate]) VALUES (N'01-01-2018', N'12-31-2018')
