﻿CREATE TABLE [dbo].[WorkDays] (
    [Id]          INT          NOT NULL,
    [Name]        VARCHAR (20) NULL,
    [WorkDayType] VARCHAR (20) NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

