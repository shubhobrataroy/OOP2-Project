﻿CREATE TABLE [dbo].[LeaveTypes] (
    [LeaveType] VARCHAR (20) NOT NULL,
    PRIMARY KEY CLUSTERED ([LeaveType] ASC)
);

