﻿CREATE TABLE [dbo].[Holidays] (
    [Name]             VARCHAR (20) NULL,
    [Start Date]       DATE         NULL,
    [End Date]         DATE         NULL,
    [Holiday Type]     VARCHAR (12) NOT NULL,
    [Repeats Annually] VARCHAR (3)  NULL
);

