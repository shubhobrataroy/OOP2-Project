﻿alter table Holidays
ADD Selected BOOLEAN